package com.example.drawingfun

import android.os.Bundle
import android.view.Menu
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI

/**
 * This is demo code to accompany the Mobiletuts+ tutorial series:
 * - Android SDK: Create a Drawing App
 * - extended for follow-up tutorials on using patterns and opacity
 *
 * Sue Smith
 * August 2013 / September 2013
 *
 */
class MainActivity : AppCompatActivity() {
    //custom drawing view
    private var drawView: DrawingView? = null

    //buttons
    private var currPaint: ImageButton? = null
    private var drawBtn: ImageButton? = null
    private var eraseBtn: ImageButton? = null
    private var arrowBtn: ImageButton? = null
    private var newBtn: ImageButton? = null
    private var saveBtn: ImageButton? = null
    private var opacityBtn: ImageButton? = null
    private var bPanelState: Int? = null

    //sizes
    private var smallBrush = 0f
    private var mediumBrush = 0f
    private var largeBrush = 0f
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val navController = findNavController(R.id.main_nav_host_frag)
        NavigationUI.setupActionBarWithNavController(this, navController)

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        //getMenuInflater().inflate(R.menu.main, menu);
        return true
    }


    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.main_nav_host_frag)
        return navController.navigateUp()
    }



}