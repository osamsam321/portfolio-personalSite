package com.example.drawingfun

//
import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController


// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [MainDrawFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class MainDrawFragment : Fragment(), View.OnClickListener  {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null
    private var viewCreated = false
    private var drawView: DrawingView? = null

    //buttons
    private var currPaint: ImageButton? = null
    private var drawBtn: ImageButton? = null
    private var eraseBtn: ImageButton? = null
    private var arrowBtn: ImageButton? = null
    private var newBtn: ImageButton? = null
    private var saveBtn: ImageButton? = null
    private var opacityBtn: ImageButton? = null
    private var bPanelState:Int? = null
    private var bottomPanel:LinearLayout? = null
    //sizes
    private var smallBrush = 0f
    private var mediumBrush = 0f
    private var largeBrush = 0f
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_main_draw, container, false)
    }

    fun paintClicked(view: View) {
        drawView?.setErase(false)
        drawView?.paintAlpha = 100
        drawView?.setBrushSize(drawView!!.lastBrushSize)
        if (view !== currPaint) {
            val imgView = view as ImageButton
            val color = view.getTag().toString()
            drawView?.setColor(color, activity?.packageName)
            //update ui
            imgView.setImageDrawable(resources.getDrawable(R.drawable.paint_pressed))
            currPaint?.setImageDrawable(resources.getDrawable(R.drawable.paint))
            currPaint = view
        }
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        (activity as AppCompatActivity?)!!
                .supportActionBar?.title = "Easy Draw"
        (activity as AppCompatActivity?)!!
                .supportActionBar?.setBackgroundDrawable( ColorDrawable(Color.parseColor("#40E0D0")))

    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        bPanelState = 1
        //get drawing view
        drawView = view?.findViewById<View>(R.id.drawing) as? DrawingView

        //get the palette and first color button
        val paintLayout1 = view.findViewById<View>(R.id.paint_colors_1) as LinearLayout
        val paintLayout2 = view.findViewById<View>(R.id.paint_colors_2) as LinearLayout
        currPaint = paintLayout1.getChildAt(0) as ImageButton
        currPaint!!.setImageDrawable(resources.getDrawable(R.drawable.paint_pressed))
        var imgBtn:ImageButton
        for (i in 0..paintLayout1.childCount)
        {
            if(paintLayout1.getChildAt(i) != null) {
                paintLayout1.getChildAt(i).setOnClickListener(View.OnClickListener { paintClicked(paintLayout1.getChildAt(i)) })
            }
        }
        for (i in 0..paintLayout2.childCount)
        {
            if(paintLayout1.getChildAt(i) != null) {
                paintLayout2.getChildAt(i).setOnClickListener(View.OnClickListener { paintClicked(paintLayout2.getChildAt(i)) })
            }
        }

        //sizes from dimensions
        smallBrush = 5.toFloat()
        mediumBrush = 25.toFloat()
        largeBrush = 44.toFloat()

        //draw button
        drawBtn = view?.findViewById<View>(R.id.draw_btn) as? ImageButton
        drawBtn?.setOnClickListener(this)

        //set initial size
        drawView?.setBrushSize(mediumBrush)

        //erase button
        eraseBtn = view?.findViewById<View>(R.id.erase_btn) as? ImageButton
        eraseBtn?.setOnClickListener(this)

        //new button
        newBtn = view?.findViewById<View>(R.id.new_btn) as? ImageButton
        newBtn?.setOnClickListener(this)

        bottomPanel = view?.findViewById<View>(R.id.bottom_panel) as? LinearLayout
        //opacity
        opacityBtn = view?.findViewById<View>(R.id.opacity_btn) as? ImageButton
        opacityBtn?.setOnClickListener(this)

        // arrow button
        arrowBtn = view?.findViewById<View>(R.id.arrow_btn) as? ImageButton
        arrowBtn?.setOnClickListener(this)

    }


    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment MainDrawFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                MainDrawFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onClick(view: View?) {
        val navController = findNavController()
        var buttonClicked: MutableList<Boolean> = mutableListOf(false, false, false)
        val dialog = activity?.let { Dialog(it) }
        var applyBtn:Button? = null
        var seekBar:SeekBar? = null
        var fontSizeTextView:TextView? = null
        if(view?.id == R.id.paint_colors_1)
        {
            Log.i("event clicked", "paint color selected")
            paintClicked(view)
        }

        if(view?.id == R.id.draw_btn || view?.id == R.id.erase_btn)
        {
            dialog?.setContentView(R.layout.brush_chooser_1)
            var smallBtn = dialog?.findViewById<View>(R.id.small_brush_1) as ImageButton?
            var mediumBtn = dialog?.findViewById<View>(R.id.medium_brush_1) as ImageButton?
            var largeBtn = dialog?.findViewById<View>(R.id.large_brush_1) as ImageButton?
            fontSizeTextView = dialog?.findViewById<View>(R.id.font_size_textview) as TextView

            var applyBtn = dialog.findViewById<View>(R.id.apply_btn) as Button
            seekBar = dialog?.findViewById<View>(R.id.seekBar_font_size) as SeekBar
            seekBar.progress = drawView!!.lastBrushSize.toInt()
            fontSizeTextView.text = seekBar.progress.toString()
            applyBtn = dialog.findViewById<View>(R.id.apply_btn) as Button

            applyBtn.setOnClickListener {
                dialog.dismiss()
            }
            smallBtn?.setOnClickListener {
                smallBtn?.setBackgroundColor(Color.rgb(0, 200, 200))
                mediumBtn?.setBackgroundColor(Color.rgb(220, 220, 220))
                largeBtn?.setBackgroundColor(Color.rgb(220, 220, 220))
                drawView!!.setBrushSize(smallBrush)
                seekBar.progress = smallBrush.toInt()
                drawView!!.lastBrushSize= smallBrush
                buttonClicked[0] = true
                configBtn(view!!);
            }
            mediumBtn?.setOnClickListener {
                smallBtn?.setBackgroundColor(Color.rgb(220, 220, 220))
                mediumBtn?.setBackgroundColor(Color.rgb(0, 200, 200))
                largeBtn?.setBackgroundColor(Color.rgb(220, 220, 220))
                drawView!!.setBrushSize(mediumBrush)
                drawView!!.lastBrushSize= mediumBrush
                seekBar.progress = mediumBrush.toInt()
                buttonClicked[1] = true
                configBtn(view!!);
            }
            largeBtn?.setOnClickListener {
                smallBtn?.setBackgroundColor(Color.rgb(220, 220, 220))
                mediumBtn?.setBackgroundColor(Color.rgb(220, 220, 220))
                largeBtn.setBackgroundColor(Color.rgb(0, 200, 200))
                drawView!!.setBrushSize(largeBrush)
                drawView!!.lastBrushSize= largeBrush
                seekBar.progress = largeBrush.toInt()
                buttonClicked[2] = true
                configBtn(view!!);
            }
            seekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    configBtn(view!!)
                    drawView?.setBrushSize(seekBar.progress.toFloat())
                    drawView?.setBrushSize(seekBar.progress.toFloat())
                    drawView?.lastBrushSize = seekBar.progress.toFloat()
                    fontSizeTextView.text = seekBar.progress.toString()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar) {
                }

                override fun onStopTrackingTouch(seekBar: SeekBar) {
                }
            })

            dialog?.show()
        }

        if (view?.id == R.id.draw_btn) {
            //draw button clicked
            dialog?.setTitle("Brush size:")
            if(buttonClicked[0])
            {
                drawView!!.setErase(false)

                buttonClicked[0] = false
            }

            if(buttonClicked[1])
            {
                drawView!!.setErase(false)
                drawView!!.lastBrushSize = mediumBrush
                buttonClicked[1] = false
            }

            if(buttonClicked[2])
            {
                drawView!!.setErase(false)
                drawView!!.lastBrushSize = largeBrush
                buttonClicked[2] = false
            }
            //show and wait for user interaction
        }

        else if (view?.id == R.id.erase_btn) {
            //switch to erase - choose size

            dialog?.setTitle("Eraser size:")
            //size buttons
            if(buttonClicked[0]) {
                drawView!!.setErase(true)
                Log.i("error", "inside of small eraser case")
                buttonClicked[0] = false
            }
            if(buttonClicked[1]) {
                drawView!!.setErase(true)
                buttonClicked[1] = false
            }
            if(buttonClicked[2]) {
                drawView!!.setErase(true)
                buttonClicked[2] = false
            }

        }

        else if (view?.id == R.id.new_btn) {
            //new button
            val newDialog = AlertDialog.Builder(activity)
            newDialog.setTitle("New drawing")
            newDialog.setMessage("Start new drawing (you will lose the current drawing)?")
            newDialog.setPositiveButton("Yes") { dialog, which ->
                drawView!!.startNew()
                dialog.dismiss()
            }
            newDialog.setNegativeButton("Cancel") { dialog, which -> dialog.cancel() }
            newDialog.show()
        }
        else if (view?.id == R.id.opacity_btn) {
            //launch opacity chooser
            val seekDialog = activity?.let { Dialog(it) }

            seekDialog?.setTitle("Opacity level:")
            seekDialog?.setContentView(R.layout.opacity_chooser)
            //get ui elements
            val seekTxt = seekDialog?.findViewById<View>(R.id.opq_txt) as TextView
            val seekOpq = seekDialog.findViewById<View>(R.id.opacity_seek) as SeekBar
            //set max
            seekOpq.max = 100
            //show current level
            val currLevel = drawView?.paintAlpha
            seekTxt.text = "$currLevel%"
            if (currLevel != null) {
                seekOpq.progress = currLevel
            }
            //update as user interacts
            seekOpq.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    seekTxt.text = Integer.toString(progress) + "%"
                }

                override fun onStartTrackingTouch(seekBar: SeekBar) {}
                override fun onStopTrackingTouch(seekBar: SeekBar) {}
            })
            //listen for clicks on ok
            val opqBtn = seekDialog.findViewById<View>(R.id.opq_ok) as Button
            opqBtn.setOnClickListener {
                drawView?.paintAlpha = seekOpq.progress
                seekDialog.dismiss()
            }
            //show dialog
            seekDialog.show()
        }

        else if(view?.id == R.id.arrow_btn)
        {
            bPanelState = (bPanelState?.plus(1))?.rem(2)
            val view: View? = view?.findViewById(R.id.bottom_panel)
            if(bPanelState == 1)
            {
                bottomPanel?.visibility = View.VISIBLE
            }
            else
            {
                bottomPanel?.visibility = View.GONE
            }

        }

        else if(view?.id == R.id.apply_btn)
        {
            dialog?.dismiss()
        }
    }
    fun configBtn(view: View)
    {
        if(view.id ==R.id.draw_btn )
        {
            drawView!!.setErase(false)
        }
        else if(view.id == R.id.erase_btn)
        {
            drawView!!.setErase(true)
        }
    }
}


