package com.example.drawingfun

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.util.Log
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View

/**
 * This is demo code to accompany the Mobiletuts+ tutorial series:
 * - Android SDK: Create a Drawing App
 * - extended for follow-up tutorials on using patterns and opacity
 *
 * Sue Smith
 * August 2013 / September 2013
 *
 */
class DrawingView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {
    //drawing path
    private var drawPath: Path? = null

    //drawing and canvas paint
    private var drawPaint: Paint? = null
    private var canvasPaint: Paint? = null

    //initial color
    private var paintColor = -0x9a0000


    //set alpha
    //return current alpha
    var paintAlpha = 255
        get() = Math.round(field.toFloat() / 255 * 100)
        set(newAlpha) {
            field = Math.round(newAlpha.toFloat() / 100 * 255)
            drawPaint!!.color = paintColor
            drawPaint!!.alpha = paintAlpha
        }

    //canvas
    private var drawCanvas: Canvas? = null

    //canvas bitmap
    companion object {var canvasBitmap: Bitmap? = null}

    //brush sizes
    private var brushSize = 0f

    //get and set last brush size
    var lastBrushSize = 0f

    //erase flag
    private var erase = false

    //setup drawing
    private fun setupDrawing() {

        //prepare for drawing and setup paint stroke properties
        brushSize = resources.getInteger(R.integer.medium_size).toFloat()
        lastBrushSize = brushSize
        drawPath = Path()
        drawPaint = Paint()
        drawPaint!!.color = paintColor
        drawPaint!!.isAntiAlias = true
        drawPaint!!.strokeWidth = brushSize
        drawPaint!!.style = Paint.Style.STROKE
        drawPaint!!.strokeJoin = Paint.Join.ROUND
        drawPaint!!.strokeCap = Paint.Cap.ROUND
        canvasPaint = Paint(Paint.DITHER_FLAG)
    }

    //size assigned to view
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        canvasBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        if(canvasBitmap != null)
        {
            drawCanvas = Canvas(canvasBitmap!!)
        }

    }

    //draw the view - will be called after touch event
    override fun onDraw(canvas: Canvas) {
        canvas.drawBitmap(canvasBitmap!!, 0f, 0f, canvasPaint)
        canvas.drawPath(drawPath!!, drawPaint!!)
    }

    //register user touches as drawing action
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val touchX = event.x
        val touchY = event.y
        when (event.action) {
            MotionEvent.ACTION_DOWN -> drawPath!!.moveTo(touchX, touchY)
            MotionEvent.ACTION_MOVE -> drawPath!!.lineTo(touchX, touchY)
            MotionEvent.ACTION_UP -> {
                drawPath!!.lineTo(touchX, touchY)
                drawCanvas!!.drawPath(drawPath!!, drawPaint!!)
                drawPath!!.reset()
            }
            else -> return false
        }
        //redraw
        invalidate()
        return true
    }

    //update color
    fun setColor(newColor: String,packageName:String?) {
        invalidate()
        //check whether color value or pattern name
        if (newColor.startsWith("#")) {
            paintColor = Color.parseColor(newColor)
            drawPaint!!.color = paintColor
            drawPaint!!.shader = null
        } else {
            //pattern
            val patternID = resources.getIdentifier(
                    newColor, "drawable",packageName )

            //decode
            Log.i("ID","ID: " + patternID.toString())
            val patternBMP = BitmapFactory.decodeResource(resources, patternID)
            //create shader
            val patternBMPshader = BitmapShader(patternBMP,
                    Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            //color and shader
            drawPaint!!.color = -0x1
            drawPaint!!.shader = patternBMPshader
        }
    }

    //set brush size
    fun setBrushSize(newSize: Float) {
        val pixelAmount = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                newSize, resources.displayMetrics)
        brushSize = pixelAmount
        drawPaint!!.strokeWidth = brushSize
    }

    //set erase true or false
    fun setErase(isErase: Boolean) {
        erase = isErase
        if (erase) drawPaint!!.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) else drawPaint!!.xfermode = null
    }

    //start new drawing
    fun startNew() {
        drawCanvas!!.drawColor(0, PorterDuff.Mode.CLEAR)
        invalidate()
    }

    init {
        setupDrawing()
    }
}