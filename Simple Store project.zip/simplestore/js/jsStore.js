	$(document).ready(function(){
	setTimeout(function(){

	$("#titleStatement2").hide().fadeIn(2000);
	$("#titleStatement1").hide().fadeIn(3000);
	$(".topBackgroundImg").hide().fadeIn(4000); 
	$(".PDodd").hide().fadeIn(5000);
	$ (".parOdd").hide().fadeIn(5500)
	$(".PDeven").hide().fadeIn(7000);
	$(".parEven").hide().fadeIn(7500);
	$("#midGreyBoxPD h1").hide().fadeIn(3000);
	$("#midGreyBoxPD h3").hide().fadeIn(3000);



	


	});
});  
	$("#")
	function scrollFunction()
{

	document.body.scrollTop = 0;
	document.documentElement.scrollTop = 0;

} 





	






	



