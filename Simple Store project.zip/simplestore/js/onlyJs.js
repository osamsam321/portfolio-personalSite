function GetPrice(){
 var price1 = "$15.00";
 var price2 = "$25.00";
 var collect = document.getElementById("selectGames").value;

  
 	if(collect == 1) {
 document.getElementById("priceChange").innerHTML = "$15.00/month";
	 	}
 else{
  document.getElementById("priceChange").innerHTML = "$25.00/month";
  		


	}
}

	var modalDisplay = document.getElementById('moda');
var purchase =document.getElementById("buttonPurchase");
var button = document.getElementById("displayModalBtn");
var closeButton = document.getElementById("closeBtn");
var purchaseModal = document.getElementById('purchaseService');

button.onclick = function() {
    modalDisplay.style.display = "block";

}
closeButton.onclick = function(){
	modalDisplay.style.display = "none";
} 

purchase.onclick = function(){
	modalDisplay.style.display = "block";
}
